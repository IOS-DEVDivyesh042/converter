//
//  Powervc.swift
//  EnerGaugePro
//
//  Created by Manish Bhanushali on 03/11/23.
//

import UIKit

class Powervc: UIViewController {
    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var outputLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    
    }
    

    @IBAction func convertToWatts(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 1.0, unitName: "Watts")
    }

    @IBAction func convertToKilowatts(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 0.001, unitName: "Kilowatts")
    }

    @IBAction func convertToHorsepower(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 0.00134102, unitName: "Horsepower")
    }

    @IBAction func convertToBTUsPerHour(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 3.412142, unitName: "BTUs per hour")
    }

    @IBAction func convertToFootPoundsPerSecond(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 737.562, unitName: "Foot-Pounds per Second")
    }

    func convertToUnit(unitTag: Int, conversionFactor: Double, unitName: String) {
        guard let inputValueText = inputTextField.text,
              let inputValue = Double(inputValueText) else {
            outputLabel.text = "Invalid input"
            return
        }

        let result = inputValue * conversionFactor
        outputLabel.text = "\(inputValue) \(unitName) is equal to \(result) Watts"
    }
}


