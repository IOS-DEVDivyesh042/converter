//
//  ViewController.swift
//  EnerGaugePro
//
//  Created by Manish Bhanushali on 02/11/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var btnenergy: UIButton!
    
    
    @IBOutlet weak var btnangel: UIButton!
    
    
    @IBOutlet weak var btnpower: UIButton!
    
    @IBOutlet weak var btnpressure: UIButton!
    
    @IBOutlet weak var view1: UIView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view1.layer.cornerRadius = 30
        btnangel.layer.cornerRadius = 10
        btnpower.layer.cornerRadius = 10
        btnenergy.layer.cornerRadius = 10
        btnpressure.layer.cornerRadius = 10
        
        
    }
    
    @IBAction func energybtn(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "Energyvc") as! Energyvc
        navigationController!.pushViewController(nextvc, animated: true)
    
    }
    
    
    @IBAction func angelbtn(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "Angelvc") as! Angelvc
        navigationController!.pushViewController(nextvc, animated: true)
    
    }
    
    @IBAction func powerbtn(_ sender: Any) {
    
    let nextvc = storyboard?.instantiateViewController(withIdentifier: "Powervc") as! Powervc
    navigationController!.pushViewController(nextvc, animated: true)
}
    
    @IBAction func pressurebtn(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "Pressurevc") as! Pressurevc
        navigationController!.pushViewController(nextvc, animated: true)
    
    }
    


}

