//
//  Angelvc.swift
//  EnerGaugePro
//
//  Created by Manish Bhanushali on 03/11/23.
//

import UIKit

class Angelvc : UIViewController {
    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var outputLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func convertToDegrees(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 1.0, unitName: "Degrees")
    }

    @IBAction func convertToRadians(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 0.0174533, unitName: "Radians")
    }

    @IBAction func convertToGradians(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 1.11111, unitName: "Gradians")
    }

    @IBAction func convertToArcminutes(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 60.0, unitName: "Arcminutes")
    }

    @IBAction func convertToArcseconds(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 3600.0, unitName: "Arcseconds")
    }

    func convertToUnit(unitTag: Int, conversionFactor: Double, unitName: String) {
        guard let inputValueText = inputTextField.text,
              let inputValue = Double(inputValueText) else {
            outputLabel.text = "Invalid input"
            return
        }

        let result = inputValue * conversionFactor
        outputLabel.text = "\(inputValue) \(unitName) is equal to \(result) Degrees"
    }
}
