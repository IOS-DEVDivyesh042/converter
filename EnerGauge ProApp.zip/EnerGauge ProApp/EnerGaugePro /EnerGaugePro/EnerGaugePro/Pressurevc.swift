//
//  Pressurevc.swift
//  EnerGaugePro
//
//  Created by Manish Bhanushali on 03/11/23.
//

import UIKit

class Pressurevc : UIViewController {
    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var outputLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    

    @IBAction func convertToPascals(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 1.0, unitName: "Pascals")
    }

    @IBAction func convertToKilopascals(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 0.001, unitName: "Kilopascals")
    }

    @IBAction func convertToBars(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 0.00001, unitName: "Bars")
    }

    @IBAction func convertToPSI(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 0.0001450377377338, unitName: "PSI")
    }

    @IBAction func convertToAtmospheres(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 9.8692326671601e-6, unitName: "Atmospheres")
    }

    func convertToUnit(unitTag: Int, conversionFactor: Double, unitName: String) {
        guard let inputValueText = inputTextField.text,
              let inputValue = Double(inputValueText) else {
            outputLabel.text = "Invalid input"
            return
        }

        let result = inputValue * conversionFactor
        outputLabel.text = "\(inputValue) \(unitName) is equal to \(result) Pascals"
    }
}
