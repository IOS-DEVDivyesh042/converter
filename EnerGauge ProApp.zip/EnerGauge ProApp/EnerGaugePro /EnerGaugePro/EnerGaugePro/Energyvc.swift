//
//  Energyvc.swift
//  EnerGaugePro
//
//  Created by Manish Bhanushali on 03/11/23.
//
import UIKit

class Energyvc : UIViewController {
    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var outputLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func convertToJoules(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 1.0, unitName: "Joules")
    }

    @IBAction func convertToKilojoules(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 0.001, unitName: "Kilojoules")
    }

    @IBAction func convertToCalories(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 4.184, unitName: "Calories")
    }

    @IBAction func convertToWattHours(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 3600.0, unitName: "Watt-Hours")
    }

    @IBAction func convertToElectronvolts(_ sender: UIButton) {
        convertToUnit(unitTag: sender.tag, conversionFactor: 1.60218e-19, unitName: "Electronvolts")
    }

    func convertToUnit(unitTag: Int, conversionFactor: Double, unitName: String) {
        guard let inputValueText = inputTextField.text,
              let inputValue = Double(inputValueText) else {
            outputLabel.text = "Invalid input"
            return
        }

        let result = inputValue * conversionFactor
        outputLabel.text = "\(inputValue) \(unitName) is equal to \(result) Joules"
    }
}
