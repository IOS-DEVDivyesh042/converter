//
//  ViewController.swift
//  DiverseMate
//
//  Created by Manish Bhanushali on 11/11/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var btn1: UIButton!
    
    @IBOutlet weak var btn2: UIButton!
    
    
    @IBOutlet weak var btn3: UIButton!
    
    
    @IBOutlet weak var btn4: UIButton!
    
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var lbl1: UILabel!
    
    
    @IBOutlet weak var lbl2: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btn1.layer.cornerRadius = 10
        btn2.layer.cornerRadius = 10
        btn3.layer.cornerRadius = 10
        btn4.layer.cornerRadius = 10
        
        view1.layer.cornerRadius = 10
        view2.layer.cornerRadius = 10
        
    }
    
    
    @IBAction func btnsoun(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "Sounspeed")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    @IBAction func btnfreq(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "frequency")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    
    @IBAction func btntime(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "TimeZone")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    @IBAction func btnclo(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "Clothing")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    


}

