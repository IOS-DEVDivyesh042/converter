//
//  frequency.swift
//  Converzilla
//
//  Created by Manish Bhanushali on 07/11/23.
//

import UIKit

class frequency : UIViewController {
    @IBOutlet var inputTextField: UITextField!
    @IBOutlet var unitPicker: UIPickerView!
    @IBOutlet var resultLabel: UILabel!

    // Define the frequency units for this converter
    let frequencyUnits = ["Hertz (Hz)", "Kilohertz (kHz)", "Megahertz (MHz)", "Gigahertz (GHz)", "Terahertz (THz)"]
    let conversionFactors: [Double] = [1.0, 1.0e3, 1.0e6, 1.0e9, 1.0e12]

    override func viewDidLoad() {
        super.viewDidLoad()
        unitPicker.dataSource = self
        unitPicker.delegate = self
    }

    @IBAction func convertButtonTapped(_ sender: UIButton) {
        if let inputText = inputTextField.text, let inputValue = Double(inputText) {
            let selectedUnitIndex = unitPicker.selectedRow(inComponent: 0)
            let conversionFactor = conversionFactors[selectedUnitIndex]
            let resultValue = inputValue * conversionFactor
            resultLabel.text = "\(inputValue) \(frequencyUnits[selectedUnitIndex]) = \(resultValue)"
        } else {
            resultLabel.text = "Invalid input"
        }
    }
}

extension frequency : UIPickerViewDataSource, UIPickerViewDelegate {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return frequencyUnits.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return frequencyUnits[row]
    }
}




