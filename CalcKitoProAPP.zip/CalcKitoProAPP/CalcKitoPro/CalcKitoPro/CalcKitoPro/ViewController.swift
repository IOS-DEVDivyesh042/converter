//
//  ViewController.swift
//  CalcKitoPro
//
//  Created by Manish Bhanushali on 05/11/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var view1: UIView!
    
    @IBOutlet weak var view2: UIView!
    
    
    @IBOutlet weak var btns: UIButton!
    
    @IBOutlet weak var btnc: UIButton!
    
    
    @IBOutlet weak var btntra: UIButton!
    
    @IBOutlet weak var btntemp: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        btnc.layer.cornerRadius = 20
        btns.layer.cornerRadius = 20
        btntra.layer.cornerRadius = 20
        btntemp.layer.cornerRadius = 20
        view1.layer.cornerRadius = 20
        view1.layer.borderColor = UIColor.black.cgColor
        view1.layer.borderWidth = 4
        view2.layer.cornerRadius = 20
        view2.layer.borderColor = UIColor.orange.cgColor
        view2.layer.borderWidth = 4
        
    }
    
    
    @IBAction func btnsph(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "Areaofsphere")
        self.navigationController?.pushViewController(nextvc!, animated: true)
        
    }
    
    @IBAction func btncylin(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "Areaofcylinder")
        self.navigationController?.pushViewController(nextvc!, animated: true)
        
    }
    
    
    @IBAction func btntrapa(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "Areaoftrapezuim")
        self.navigationController?.pushViewController(nextvc!, animated: true)
        
    }
    
    
    @IBAction func btnTempr(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "Temp")
        self.navigationController?.pushViewController(nextvc!, animated: true)
        
    }
    


}

