//
//  ViewController.swift
//  Converzilla
//
//  Created by Manish Bhanushali on 07/11/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var btnph: UIButton!
    
    @IBOutlet weak var btnpress: UIButton!
    
    @IBOutlet weak var btnss: UIButton!
    
    @IBOutlet weak var btnfreq: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btnph.layer.cornerRadius  = 20
        btnph.layer.borderWidth = 5
        btnph.layer.borderColor = UIColor.black.cgColor
        
        
        btnss.layer.cornerRadius  = 20
        btnss.layer.borderWidth = 5
        btnss.layer.borderColor = UIColor.black.cgColor
        
        
        btnfreq.layer.cornerRadius  = 20
        btnfreq.layer.borderWidth = 5
        btnfreq.layer.borderColor = UIColor.black.cgColor
        
        btnpress.layer.cornerRadius  = 20
        btnpress.layer.borderWidth = 5
        btnpress.layer.borderColor = UIColor.black.cgColor
        
        
    }
    
    @IBAction func phbtn(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "Ph")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    @IBAction func pressbtn(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "Pressure")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    
    @IBAction func ssbtn(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "Sounspeed")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    @IBAction func freqbtn(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "frequency")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    
    
    
    


}

